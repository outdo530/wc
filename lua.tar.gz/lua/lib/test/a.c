#include "a.h"
#include "b.h"

#include <stdlib.h>

abc_t * init(){
   return (abc_t*)calloc(1, sizeof(abc_t)); 
}

int abc_free(abc_t * ptr){
    free(ptr);
}
