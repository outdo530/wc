#include <stdio.h>
#include <stdlib.h>

#include "a.h"


int  func(unsigned long long  n)
{
    if(n == 1)
        return 0;
    if(n % 2 == 0)
        return 1 + func(n/2);
    int x = func(n + 1);
    int y = func(n - 1);
    if(x > y)
        return y+1;
    else
        return x+1;
}


static int * p;
int map_func(unsigned int n){
    if(p[n]) return p[n];

    if(n == 1){
        p[n] = 0;
        return 0;
    }
    if(n % 2 == 0){
        p[n] = 1 + map_func(n/2);
        return p[n];
    }
    int x = map_func(n + 1);
    int y = map_func(n - 1);
    p[n] = (x > y) ? y + 1 : x + 1;
    return p[n];
}


int main(int argc, const char * argv){

    abc_t * ptr = init();
    abc_free(ptr);
    unsigned long long  n = 72057594037927937;
#define MAX_N 128 * 1024 * 1024
    printf("time is %d\n", func(n));
/*
    if(p == NULL) {
        p = (int*)calloc(MAX_N, sizeof(int));
    }
    if(n < MAX_N){
        map_func(n);
    }
    free(p);
    */
    return 0;
}
