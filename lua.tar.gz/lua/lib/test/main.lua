#!/usr/local/bin/lua 

function get_min(n)
    if n == 1 then  return 0 end
    if n%2 == 0 then  return 1 + get_min(n/2) end
    local x = get_min(n - 1)
    local y = get_min(n + 1)
    return  x > y and  1 + y or 1 + x
end

local map = {}

function get_min_map(n)
    if map[n] ~= nil  then return map[n] end 

    if n == 1 then 
        map[n] = 0
        return 0
    end 
    if n%2 == 0 then  
        map[n] =   1 + get_min_map(n/2)
        return map[n]
    end

    local x = get_min_map(n - 1)
    local y = get_min_map(n + 1)
    map[n] = x > y and 1 + y or 1 + x
    return map[n]
end

--local max_val = 1200000000000000000000000000000000000000000000
local max_val = 72057594037927937
print(get_min_map(max_val))
---[[
for i,v in pairs(map) do 
    print(i,v)
end
--]]

--print(get_min(max_val))



