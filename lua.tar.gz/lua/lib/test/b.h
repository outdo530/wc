typedef struct abc_s {
 int a;
 int b;
} abc_t;
