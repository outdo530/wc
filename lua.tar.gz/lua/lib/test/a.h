
typedef struct abc_s abc_t;


abc_t * init();

int abc_free(abc_t * ptr);
