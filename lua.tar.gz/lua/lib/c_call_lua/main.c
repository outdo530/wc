#include <stdio.h>
#include <stdlib.h>

typedef struct array_s{
    int size_;
    int array_[0];
} array_t;

static array_t * new_array(int sz){
    array_t *  ptr =  (array_t *)calloc(1, sizeof(array_t) + sizeof(int)*sz);
    return ptr;
}

static int get_size(array_t * ptr){
    return ptr->size_;
}
static int get(array_t * ptr, int index, int * val){
    if(index >= 0 && index < ptr->size_){
        *val =  ptr->array_[index];
        return 0;
    }
    return  -1;
}
static int set(array_t * ptr, int index, int val){
    if(index >= 0 && index < ptr->size_){
        ptr->array_[index] = val;
        return 0;
    }
    return  -1;
}

#include <lualib.h>
#include <lauxlib.h>

int luaopen_array(lua_State * L){
    return 0;
}



int main(int argc, const char * argv){
    //1. create L
    //2. register L with lib
    return 0;
}
