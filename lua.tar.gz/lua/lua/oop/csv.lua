#!/usr/local/bin/lua


local print = print
local setmetatable = setmetatable
local ipairs = ipairs
local pairs = pairs
local io = io
local string = string
module(... or "csv")


local function __default_cb (fields, line_no) 
    for i, v in ipairs(fields) do 
        print(string.format("default cb:%d:%d:    [%s]", line_no, i, v)) 
    end 
end

function new(self, obj)
    obj = obj or {}
    setmetatable(obj, self)
    self.__index = self

    obj.cb = obj.cb or __default_cb
    obj.sep = obj.sep or ","
    return obj
end

local function __split_line(sep, line)
    local fields = {}
    local pattern = string.format("([^%s]+)", sep)
    string.gsub(line, pattern, function(c) fields[#fields+1] = c end)
    return fields
end

function run(self)
    if not self.file then return -1, "file is null" end
    local line_no = 0
    for line in io.lines(self.file) do
        line_no = line_no + 1
        local err = self.cb(__split_line(self.sep, line), line_no) 
        if err == -1 then return -1, "cb return failed (not zero)" end
    end
end


--[[  Test Case
c = _M:new({file="abc", sep=','})
local errno, msg  = c:run()
if errno == -1 then 
    print(msg)
end
--]]

--for k ,v in pairs(_M) do print(k,v) end
