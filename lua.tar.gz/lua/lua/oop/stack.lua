#!/usr/bin/env lua

local setmetatable = setmetatable
local print = print
local table = table

local pairs = pairs
module(... or "stack")

-- usage: s = stack:new()
function new(self, obj) 
    obj = obj or {}
    setmetatable(obj ,self)
    self.__index = self
    --for k,v in pairs(self) do print("new : " .. k,v) end
    obj.top = 0;
    obj.base = 1000;
    return obj
end

function push(self, val)
    for k,v in pairs(self) do print("hello : " .. k,v) end
    self[self.top] = val
    self.top = self.top + 1
end

function pop(self)
    if self.top <= 0 then return nil end
    local val = self[self.top-1]
    self.top = self.top - 1
    table.remove(self)
    return val
end

function size(self)
    return self.top
end

--usage: s = stack.new1() 
function new1(obj) 
    obj = obj or {}
    setmetatable(obj ,_M)
    _M.__index = _M
    obj.top = 0;
    obj.base = 1000;
    return obj
end

print("meta :", _M)
for k,v in pairs(_M) do print(k,v) end

--[[
s = S:new()
--print("s.base" .. s.base)
s:size()
print("size " .. s:size())
s:push(10000)
print("size " .. s:size())
print("pop value : " .. s:pop())
print("size " .. s:size())


s2 = S:new()
print("s2.base" .. s2.base) -- base is not in the local ,so find the index
s2.base = 10
print("after set s2.base = 10, s2 is :" .. s2.base)
print("after set s2.base = 10, s is " .. s.base)
--]]
