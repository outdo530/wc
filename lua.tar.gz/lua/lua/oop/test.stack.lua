#!/usr/bin/env lua
require "stack"

s = stack:new()
s:size()
print("size " .. s:size())
s:push(10000)
print("size " .. s:size())
print("pop value : " .. s:pop())
print("size " .. s:size())

s2 = stack:new()
print("s base ", s.base)
s2.base = 1
print("after set s2.base =1, s base ", s.base)
print("after set s2.base =1, s2 base ", s2.base)



---[[

require("csv")
local function mycb(fields, NR)
    NF = #fields
    if NR <= 2 then 
        print("" .. NR .. " " .. NF .. " " .. fields[NF])
    end
end

c = csv:new({file="abc", sep=',', cb=mycb})
local errno, msg  = c:run()
if errno == -1 then 
    print(msg)
end
--]]
