#include <stdio.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int main(int argc, char * argv[]){
    lua_State * L = luaL_newstate();
    luaL_openlibs(L);

    const char * file = "bus.lua";
    int err = luaL_dofile(L, file);
    if(err){
        printf("%s", lua_tostring(L, -1));
        lua_pop(L, 1);
    }

    //call function
    //lua_getfield(L, LUA_GLOBALSINDEX, "call_no_ret");  
    lua_getfield(L, LUA_GLOBALSINDEX, "call_f");  

    //set a simple table  push_tab_from_hash(L, hash)
    printf("------------------ push table to call lua function:\n");
    lua_newtable(L);
    lua_pushnumber(L, 1);
    lua_setfield(L, -2, "a");

    lua_pushstring(L, "hello world");
    lua_setfield(L, -2, "b");
    lua_call(L, 1, 1);

    //get table  hash * pop_tab_to_hash(L)  --TODO : iterator the table
    printf("------------------ pop table from calling lua function:\n");
    luaL_checktype(L, -1, LUA_TTABLE);

    lua_pushnil(L);
    while(lua_next(L, -2) != 0){
//        printf("%s - %s\n", lua_typename(L, lua_type(L, -2)), lua_typename(L,lua_type(L, -1)));
        if(lua_type(L, -2) == LUA_TSTRING){
            printf(" key is %s : ", luaL_checkstring(L, -2));

            if(lua_type(L, -1) == LUA_TSTRING)
                printf(" value is %s \n", luaL_checkstring(L, -1));
            else if ( lua_type(L, -1) == LUA_TNUMBER)
                printf(" value is %d \n", luaL_checkint(L, -1));
            else
                printf(" value type need details test\n");
        }
        lua_pop(L, 1);
    }
    /*
    lua_getfield(L, -1, "ret");
    lua_getfield(L, -2, "ret_str");
    printf(" ret[ret] %d, ret[ret_str] %s\n", luaL_checkint(L, -2), luaL_checkstring(L, -1));
    */

    lua_pop(L, 3);

    lua_close(L);
    return 0;
}
