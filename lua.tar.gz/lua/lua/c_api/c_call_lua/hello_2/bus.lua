function call_no_ret()
    print ("echo from bus -- function")
end

function call_f(tab) 
    print("tab len:" .. tab.a  .. " string: " ..  tab.b)
    return {ret= 0, ret_str="hello wold"}
end

--call_f({"1"})
