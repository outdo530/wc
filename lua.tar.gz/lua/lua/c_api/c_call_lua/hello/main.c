/*
 *
 *  Edit History:
 *
 *    08/15/2015 - Created by chenglun
 *
 */
#include <stdio.h>
#include <string.h>

#include "lauxlib.h"

static void test_concat(lua_State * L){
    fprintf(stdout, "init start : stack element size %d\n", lua_gettop(L));
    lua_pushstring(L, "string");
    lua_pushstring(L, "string");
    lua_pushstring(L, "string");
    fprintf(stdout, "after push 3 str : stack element size %d\n", lua_gettop(L));
    lua_concat(L, 3);
    fprintf(stdout, "after concate : stack element size %d\n", lua_gettop(L));
    fprintf(stdout, "result %s\n", lua_tostring(L, -1));
    lua_pop(L, 1); 
}

int main(int argc, char * argv[]){
    lua_State * L = luaL_newstate();    
    luaL_openlibs(L);

    test_concat(L);

    char buf[256];
    int error = 0;
    while(fgets(buf, sizeof(buf), stdin) != NULL){
        error = luaL_loadbuffer(L, buf, strlen(buf), "line") ;
        if(error == 0){
            fprintf(stdout, "after loadbuffer, stack element size %d\n", lua_gettop(L));
            fprintf(stdout, "boolean value of top %d\n", lua_toboolean(L, -1));
            fprintf(stdout, "after toboolean:  stack element size %d\n", lua_gettop(L));
            error = lua_pcall(L, 0 , 0, 0);
        }
        if(error){
            fprintf(stderr, "%s\n", lua_tostring(L, -1));
            fprintf(stderr, "ERROR: stack element size %d\n", lua_gettop(L));
            lua_pop(L, 1);
        }
    }
    lua_close(L);
    printf("hello world\n");
    return 0;
}
