#include <stdio.h> 
#include <stdlib.h>

#include "lauxlib.h"

#define STRUCT_BUFFERMETA_NAME "meta_struct_buffer"

int array_new(lua_State * L){
    //luaL_checktype(L, 1, LUA_TTABLE);
    //  init it 
    int n = luaL_checkint(L, 1);  //1-> first args of function
    luaL_argcheck(L, n  != -1, 1,  "must be int type!");
    size_t nbytes = sizeof(array_t) + sizeof(int) * n;
    array_t * ptr = (array_t*)lua_newuserdata(L, nbytes); 

    ptr -> size_ = n;

    int i = 0;
    for( ; i < ptr->size_; ++i){
        ptr->array_[i] = 0;
    }

    // for set the meta table
    luaL_getmetatable(L, STRUCT_BUFFERMETA_NAME);
    lua_setmetatable(L, -2);
    return 1;
}

static int get_size(lua_State *L){
    array_t * ptr = (array_t *) luaL_checkudata(L, 1, STRUCT_BUFFERMETA_NAME);
    luaL_argcheck(L, ptr != NULL, 1, "user data convert into c ptr failed");
    lua_pushnumber(L, ptr->size_);
    return 1;
}
static int to_string(lua_State * L){
    array_t * ptr = (array_t *) luaL_checkudata(L, 1, STRUCT_BUFFERMETA_NAME);
    luaL_argcheck(L, ptr != NULL, 1, "user data convert into c ptr failed");
    lua_pushfstring( L, "sz:%d", ptr->size_);
    return 1;
}

static const struct luaL_reg struct_buffer_lib_m[]={
    {"size", get_size},
    {"__tostring", to_string},
    {NULL, NULL},
};

LUALIB_API int luaopen_array(lua_State * L){

    luaL_newmetatable(L, STRUCT_BUFFERMETA_NAME); //for type check
    lua_pushvalue(L, -1);
    lua_setfield(L, -2, "__index");
    luaL_register(L, NULL, struct_buffer_lib_m);
    return 1;
}
