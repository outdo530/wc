
-- common field
CM = {
    ["cmd_login_req"] = 98,
    ["cmd_login_rsp"] = 99,
    ["cmd_login_nty"] = 100,
}

FM = {
    ["trader_login_req"] = {
        ["acsvr_req_head"] = {
            [dev_id"] = 0,
            ["channel_id"] = 8,
            ["sequence_no"] = 16,
            ["root_id"] = 24,
        },
        ["trader"] = {
            ["enabled"] = 40,
            ["trader_id"] = 48,
            ["trader_name"] = 64,
            ["member_id"] = 96,
            ["password"] = 112,
        },
        ["safe_ack"] = {
        },
        ["dissemination"] = {
        },
    }
}










local tab = {
    [CM.cmd_login_req] =  function (cmd) 
        return {
            acsvr_req_head = {
                hello = "world",
                world = "world2",
                tab = {
                    sub_tab = {
                        key = 2.3,
                    },
                    key = 1,
                },
            },
            trader = {
                trader_id = cmd:get_string(FM.trader_login_req.trader.trader_id),
                --trader_name = cmd:get_longlong(FM.????)
                --trader_double = cmd:get_double(FM.)
            },
                
        }
    end,
    [CM.cmd_login_rsp] =  function (cmd) 
        return {ab='hello_99'}
    end,
    [CM.cmd_login_nty] =  function (cmd) 
        return {bc = "hello_100"}
    end,
}


function convert_to_hash(cmd)
    --local f = tab[cmd:cmd()]
    --return f or tab[cmd:cmd()](cmd)
    return tab[cmd:cmd()](cmd)
end 

--    print("...................", cmd:cmd()) -- cmd.cmd()
--    print("...................", cmd) -- tostring
--    print("...................", cmd:get_string(48)) -- tostring
