#ifndef  STRUCT_BUFFER_H
#define  STRUCT_BUFFER_H

int luaopen_structbuffer(lua_State * L);

void create_struct_buffer(lua_State * ls, void * head);

#endif   /* STRUCT_BUFFER_H */
