
#ifndef  BASE_H
#define  BASE_H


#define PRINT_GETTOP(msg, L)  
//#define PRINT_GETTOP(msg, L)  printf(msg ",top is %d\n", lua_gettop(L));
#define PRINT_ERROR     printf

#endif   /* BASE_H */
