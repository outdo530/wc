/*
 *
 *  Edit History:
 *
 *    08/15/2015 - Created by chenglun
 *
 */
#include <stdio.h>
#include <string.h>

#include "lauxlib.h"

#include "z_base_api.h"
#include "z_protocol.h"

#include "base.h"
#include "struct_buffer.h"


lua_State * g_L = NULL;
static const char *  LUA_SCRIPT_FILE_NAME = "mem.lua";
static const char *  LUA_ENTRY_FUNC_NAME = "convert_to_hash";


static int _get_function_from_script(lua_State * L, const char * file_name, const char * func_name){

    PRINT_GETTOP("load file:start  ", L);

    int err = luaL_dofile(L, file_name);
    if(err){
        PRINT_ERROR("load lua script failed: %s\n", lua_tostring(L, -1));
        PRINT_GETTOP("load file:before pop", L);
        lua_pop(L, 2);
        PRINT_GETTOP("load file:after error clear ", L);
        return -1;
    }
    PRINT_GETTOP("load file:dofile  finished ", L);
    lua_getfield(L, LUA_GLOBALSINDEX, func_name);
    PRINT_GETTOP("load file:get function finished ", L);

    PRINT_GETTOP("load file:end, get function finished", L);
    return 0;
}

static void _call_it(lua_State * L, int in, int out){
    PRINT_GETTOP("call_it:before", L);

    lua_call(L, in, out);

    PRINT_GETTOP("call_it:after", L);
}


int _get_return_tab(lua_State *L, z_hash_t * req);

static void _insert_pair(lua_State *L , z_hash_t * req, const char * key){
    switch(lua_type(L, -1)){
        case  LUA_TNIL :  
            PRINT_ERROR("key type is error! %d", lua_type(L, -1));
            break;
        case LUA_TBOOLEAN :
             zH_strinsert_ll(req, key, lua_toboolean(L, -1));
            break;
        case LUA_TLIGHTUSERDATA :
            PRINT_ERROR("key type is error! %d", lua_type(L, -1)); //TODO: error print to lua
            break;
        case LUA_TNUMBER :
             zH_strinsert_double(req, key, lua_tonumber(L, -1));
            break;
        case  LUA_TSTRING : {
            zH_strinsert_str(req, key, lua_tostring(L, -1));
            break;
        }
        case LUA_TTABLE : {
            z_hash_t * sub_req = zH_init();
            zH_strinsert(req, key, (z_obj_t*)sub_req);
            _get_return_tab(L, sub_req);
            break;
        }
        default : 
            PRINT_ERROR("key type is error! %d", lua_type(L, -2)); //TODO : error print to lua 
            break;
    }
}
#define MAX_STR_LEN         128
//get table and convert to hash
int _get_return_tab(lua_State * L, z_hash_t * req){
    char * key_buf = (char *)malloc(MAX_STR_LEN *sizeof(char));
    luaL_checktype(L, -1, LUA_TTABLE);
    lua_pushnil(L);
    while(lua_next(L, -2) != 0){
        switch(lua_type(L, -2)){
            case  LUA_TNIL :  
                PRINT_ERROR("key type is error! %d", lua_type(L, -2)); //TODO: error print to lua
                break;
            case LUA_TBOOLEAN :
                 snprintf(key_buf, MAX_STR_LEN, "%d", lua_toboolean(L, -2));
                 _insert_pair(L, req, key_buf);
                break;
            case LUA_TLIGHTUSERDATA :
                PRINT_ERROR("key type is error! %d", lua_type(L, -2)); //TODO: error print to lua
                break;
            case LUA_TNUMBER :
                 snprintf(key_buf, MAX_STR_LEN, "%f", lua_tonumber(L, -2));
                 _insert_pair(L, req, key_buf);
                break;
            case  LUA_TSTRING : {
                _insert_pair(L, req, lua_tostring(L, -2));
                break;
            }
            case LUA_TTABLE : 
                PRINT_ERROR("key type is error! %d", lua_type(L, -2)); //TODO : error print to lua 
                break;
            default : 
                PRINT_ERROR("key type is error! %d", lua_type(L, -2)); //TODO : error print to lua 
                break;
        }
        lua_pop(L, 1);
    }
    free(key_buf);
    //PRINT_GETTOP("get_return_tab ", L);
    return 0;
}

int convert_to_hash(const z_head_t * head, z_hash_t * req){
    assert(head && req && g_L);

    if(_get_function_from_script(g_L, LUA_SCRIPT_FILE_NAME, LUA_ENTRY_FUNC_NAME)){
        PRINT_ERROR("_get_function_from_script failed\n");
        return -1;
    }

    create_struct_buffer(g_L, (void *)head);

    _call_it(g_L, 1, 1);

    PRINT_GETTOP("before get_return_tab ", g_L);
    if(_get_return_tab(g_L, req)){
        PRINT_ERROR("_create_struct_buffer failed\n");
        return -1;
    }
    PRINT_GETTOP("after get_return_tab", g_L);
    lua_pop(g_L, -1); //pop the call() return value -- table
    return 0;
}

#define PRINT_HASH(req) do { \
        z_buffer_t * bf = z_hash2json(req); \
        printf("hash is %s\n", bf->ptr_);  \
        zB_free(bf); \
    }while(0);

#include "z_persudo.h"
#define  ALLOC_CMD(tp_nm, phd, pcmd) \
    z_head_t * phd = (z_head_t*)calloc(1, sizeof(z_head_t) + sizeof(cmd_##tp_nm##_t)); \
    phd->cmd_ = cmd_##tp_nm; \
    phd->content_len_ = sizeof(cmd_##tp_nm##_t);\
    cmd_##tp_nm##_t* pcmd = (cmd_##tp_nm##_t*)(phd + 1);
void test(){
    ALLOC_CMD(trader_login_req, head, cmd_req);
    strncpy(cmd_req->trader_.trader_id_, "chenglun", sizeof(cmd_req->trader_.trader_id_));
    //printf("string addr : %ld\n",  (char*)(cmd_req->trader_.trader_id_) - (char*)(cmd_req));

    long long i = 0;
    for(i = 0; i < 1000000; ++i){
        z_hash_t* req = zH_init();

        int ret = convert_to_hash(head, req);
        assert(ret == 0);
        //PRINT_HASH(req);

        zH_free(req);
    }
}

#include <unistd.h>

int main( int argc, char * argv[])
{
    g_L = luaL_newstate();    
    luaL_openlibs(g_L);

    luaopen_structbuffer(g_L);
    PRINT_GETTOP("init_struct buffer ", g_L); //?????

    test();
    sleep(100);

    lua_close(g_L);
    return 0;
}
