#include "lua.h"
#include "lauxlib.h"

static int test1(lua_State *L){
    printf("top %d\n", lua_gettop(L));
    lua_Number n = luaL_checknumber(L, -1);
    printf("test value is %f\n", n);
    lua_pushnumber(L,n);
    return 0;
}
static int test2(lua_State *L){
   printf("top %d\n", lua_gettop(L));
   lua_Number n = luaL_checknumber(L, -2);
   const char * str = luaL_checkstring(L, -1);
   printf("test value is %f, string %s\n", n, str);
   lua_pushnumber(L,n);
   lua_pushstring(L, str);
   return 2;
}
static int test3_table(lua_State *L){
   printf("top %d\n", lua_gettop(L));
   lua_Number n = luaL_checknumber(L, -3);
   const char * str = luaL_checkstring(L, -2);
   luaL_checktype(L, -1, LUA_TTABLE);
   size_t objlen = lua_objlen(L, -1);
   printf("test value is %f, string %s, table len %lu\n", n, str, objlen);
   lua_pushnumber(L, n);
   lua_pushstring(L, str);
   lua_pushnumber(L, objlen);
   return 3;
}


static int test_table(lua_State * L){
    return 0;
}

static const struct luaL_Reg bit_funcs[] = {
  { "test1",	test1 },
  { "test2",	test2 },
  { "test3_table",	test3_table},
//  { "bor",	bit_bor },
//  { "bxor",	bit_bxor },
//  { "lshift",	bit_lshift },
//  { "rshift",	bit_rshift },
//  { "arshift",	bit_arshift },
//  { "rol",	bit_rol },
//  { "ror",	bit_ror },
//  { "bswap",	bit_bswap },
//  { "tohex",	bit_tohex },
  { NULL, NULL }
};

LUALIB_API int luaopen_test(lua_State *L)
{
  luaL_register(L, "test", bit_funcs);
  return 1;
}
